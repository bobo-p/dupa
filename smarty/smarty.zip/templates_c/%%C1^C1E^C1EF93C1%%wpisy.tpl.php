<?php /* Smarty version 2.6.26, created on 2010-11-27 19:13:43
         compiled from wpisy.tpl */ ?>
<h2>Dodaj wpis</h2>
<form action="dodaj.php" method="post" >
	<div class="pole">
		<label>Nazwa</label>
		<input type="text" class="text" name="text"/>
	</div>	
	<textarea name="textarena"></textarea>
	<div class="pole">
		<input type="submit" class="submit" value="wyślij"/>
	</div>
	<hr/>
	<br/>
</form>